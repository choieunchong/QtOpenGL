#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "CustomVTKWidget.h"
#include <vtkSTLReader.h>
#include <vtkPolyDataMapper.h>
#include <QDebug>
#include <vtkProperty.h> 
#include <vtkActor.h>
#include <vtkRenderWindow.h>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    
    colors = new QColorDialog(this); //�ǽð� dialog�� �޾ƿ� ��� ���� �ʱ�ȭ

    connect(ui->open, SIGNAL(triggered(bool)), this, SLOT(open(bool))); 
   // connect(ui->color, SIGNAL(triggered(bool)), this, SLOT(change(bool)));
    connect(ui->color, &QAction::triggered, this, [this](bool) { colors->show(); }); //���� QAction�� �������� & ��� [](){} 
   // connect(this, SIGNAL(SendActor(vtkSmartPointer<vtkActor>)),this, SLOT(color(vtkSmartPointer<vtkActor>)));
    connect(colors, SIGNAL(currentColorChanged(QColor)), this, SLOT(getColor(QColor)));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::open(bool) 
{
    qDebug() << "Open!!";
    QString file = tr("stl (stl*)");
    QString filename = QFileDialog::getOpenFileName(NULL, "", "", "stl (*.stl);;  All files (*.*)");
    qDebug() << filename;
    
    vtkNew<vtkSTLReader> reader;
    reader->SetFileName(filename.toStdString().c_str());
    reader->Update();
    vtkNew<vtkPolyData> polydata;
    polydata->DeepCopy(reader->GetOutput());

    vtkNew<vtkPolyDataMapper> mapper;
    mapper->SetInputData(polydata);
    
    mactor = vtkSmartPointer<vtkActor>::New();
    mactor->SetMapper(mapper);
    mactor->GetProperty()->SetAmbientColor(10,20,30);
    mactor->GetProperty()->SetDiffuseColor(255, 255, 255); // SetDiffuseColor() 

   ui->openGLWidget->Addactor(mactor);
   qDebug() << mactor;
}

//void MainWindow::change(bool)
//{
//    qDebug() << "emit " << mactor;
//    emit(SendActor(mactor));
//
//}

//void MainWindow::color(vtkSmartPointer<vtkActor> mactor) 
//{
//    
//    colors->show();
//}
 
void MainWindow::getColor(QColor color)
{
   
  //  QColor color = QColorDialog::getColor(Qt::white, this);
    double r = color.toRgb().red();
    double g = color.toRgb().green();
    double b = color.toRgb().blue();
    mactor->GetProperty()->SetDiffuseColor(r / 255, g / 255, b / 255);
    mactor->Modified();

    ui->openGLWidget->GetRenderWindow()->Render();
}

