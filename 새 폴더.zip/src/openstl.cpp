#include "openstl.h"
#include "ui_openstl.h"

OpenSTL::OpenSTL(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::OpenSTL),
	mRenderWindow(vtkSmartPointer<vtkGenericOpenGLRenderWindow>::New()),
   stlReader(vtkSmartPointer<vtkSTLReader>::New()),
    decimarePro(vtkSmartPointer<vtkDecimatePro>::New()),
    qClustering(vtkSmartPointer<vtkQuadricClustering>::New()),
    mapper(vtkSmartPointer<vtkPolyDataMapper>::New()),
    actor(vtkSmartPointer<vtkActor>::New()),
    renderer(vtkSmartPointer<vtkRenderer>::New()),
    m_vtkWindow(vtkSmartPointer<vtkRenderWindow>::New()),
    interactor(vtkSmartPointer< vtkRenderWindowInteractor>::New())
{
    ui->setupUi(this);
	mRenderWindow->AddRenderer(renderer);
	mRenderWindow->SetInteractor(interactor);
	ui->openGLWidget->SetRenderWindow(mRenderWindow);
	//interactor->Initialize();

	QObject::connect(ui->stlpushButton, &QPushButton::clicked, this, &OpenSTL::onstlPushBottonClick);

}

OpenSTL::~OpenSTL()
{
    delete ui;
}

void OpenSTL::onstlPushBottonClick()
{

	stlReader->SetFileName("toupper.stl");
	stlReader->Update();

	decimarePro->SetInputConnection(stlReader->GetOutputPort());
	decimarePro->SetTargetReduction(0.9);
	decimarePro->PreserveTopologyOn();
	decimarePro->Update();

	qClustering->SetInputConnection(stlReader->GetOutputPort());
	qClustering->SetNumberOfDivisions(10, 10, 10);
	qClustering->Update();

	mapper->SetInputConnection(decimarePro->GetOutputPort());

	actor->SetMapper(mapper);

	renderer->AddActor(actor);
	renderer->SetBackground(.1, .2, .3);
	renderer->ResetCamera();

	ui->openGLWidget->interactor()->GetRenderWindow()->AddRenderer(renderer);
	m_vtkWindow->SetWindowName("STL");
	ui->openGLWidget->interactor()->GetRenderWindow()->SetInteractor(interactor);
	ui->openGLWidget->interactor()->SetRenderWindow(mRenderWindow);
	ui->openGLWidget->interactor()->ProcessEvents();

	renderer->AddActor(actor);
	mRenderWindow->Render();
	mRenderWindow->SetPosition(200, 200);

//	m_vtkWindow->AddRenderer(renderer);
	//m_vtkWindow->Render();

	//interactor->SetRenderWindow(m_vtkWindow);
	//ui->openGLWidget->interactor()->Start();

}
