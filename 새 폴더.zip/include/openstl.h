#ifndef OPENSTL_H
#define OPENSTL_H

#include <QWidget>


#include <vtkAutoInit.h>
#define vtkRenderingCore_AUTOINT \
4(vtkRenderingOpenGL2_AUTOINIT,vtkInteractionStyle,vtkRenderingFreeType,vtkRenderingcontextOpenGL)
#define vtkRenderingVolume_AUTOINIT 1(vtkRenderingVolumeOpenGL)
#include <vtkRenderWindow.h>
#include <vtkGenericOpenGLRenderWindow.h>
#include <vtkSmartPointer.h>
#include <vtkPolyData.h>
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include <vtkRenderer.h>
#include<vtkRenderWindowInteractor.h>
#include <vtkInteractorStyleTrackballCamera.h>
#include <vtkConeSource.h>
#include <vtkPolyDataNormals.h>
#include <vtkSTLReader.h>
#include <QtWidgets/QApplication>
#include <vtkSTLWriter.h>
#include <vtkDecimatePro.h>
#include <vtkQuadricClustering.h>
#include <QVTKInteractor.h>
#include <vtkInteractorStyle.h>

namespace Ui {
class OpenSTL;
}

class OpenSTL : public QWidget
{
    Q_OBJECT

public:
    explicit OpenSTL(QWidget *parent = nullptr);
    ~OpenSTL();

private:
    Ui::OpenSTL *ui;

    vtkSmartPointer<vtkSTLReader>stlReader;
    vtkSmartPointer<vtkGenericOpenGLRenderWindow> mRenderWindow;
    vtkSmartPointer<vtkDecimatePro>decimarePro;
    vtkSmartPointer<vtkQuadricClustering> qClustering;
    vtkSmartPointer<vtkPolyDataMapper> mapper;
    vtkSmartPointer<vtkActor> actor;
    vtkSmartPointer<vtkRenderer> renderer;
    vtkSmartPointer<vtkRenderWindow> m_vtkWindow;
    vtkSmartPointer<vtkRenderWindowInteractor>interactor;

public slots:
    void onstlPushBottonClick();

};

#endif // OPENSTL_H
