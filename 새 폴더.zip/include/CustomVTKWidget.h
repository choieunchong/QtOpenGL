#pragma once
#include <QVTKOpenGLNativeWidget.h>
#include <QVTKInteractorAdapter.h>
#include <vtkActor.h>

class CustomVTKWidget : public QVTKOpenGLNativeWidget 
{
public:
    CustomVTKWidget();
	CustomVTKWidget(QWidget* parent);
	~CustomVTKWidget();

    void Addactor(vtkSmartPointer<vtkActor>);

protected:

    
    // VTK Renderer
    vtkSmartPointer<vtkRenderer> mRenderer; 
   
    // VTK Render Window
    vtkSmartPointer<vtkGenericOpenGLRenderWindow> mRenderWindow; 
    vtkSmartPointer<QVTKInteractor> mInteractor;
    QVTKInteractorAdapter* mvtkInteractorAdapter;
};